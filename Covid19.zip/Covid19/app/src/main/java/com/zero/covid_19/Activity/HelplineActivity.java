package com.zero.covid_19.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.util.Linkify;
import android.transition.TransitionManager;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.zero.covid_19.AsyncResponse;
import com.zero.covid_19.Data.CovidData;
import com.zero.covid_19.Model.DetailsModel;
import com.zero.covid_19.R;

import java.util.List;
import java.util.Objects;

public class HelplineActivity extends AppCompatActivity implements View.OnClickListener {
    private List<DetailsModel> detailsList;
    private TableLayout tableLayout;
    private ImageButton additional;
    private ImageButton callButton;
    private ImageButton mailButton;
    private ImageButton facebookButton;
    private ImageButton twitterButton;
    private RelativeLayout titleRoot;
    private LinearLayout socialMediaRoot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fullScreenCall();
        setContentView(R.layout.activity_helpline);

        tableLayout = findViewById(R.id.helpline_table);
        callButton = findViewById(R.id.primary_contact);
        mailButton = findViewById(R.id.primary_mail);
        facebookButton = findViewById(R.id.primary_fb);
        twitterButton = findViewById(R.id.primary_twitter);
        titleRoot = findViewById(R.id.title_container_helpline);
        socialMediaRoot = findViewById(R.id.social_container);
        additional = findViewById(R.id.menu_helpline);

        twitterButton.setOnClickListener(this);
        facebookButton.setOnClickListener(this);
        mailButton.setOnClickListener(this);
        callButton.setOnClickListener(this);
        titleRoot.setOnClickListener(this);
        additional.setOnClickListener(this);

        detailsList = new CovidData().getHelplineData(new AsyncResponse() {
            @Override
            public void processFinished(List<DetailsModel> detailsList) {
                fillDetails();
            }
        });
    }

    private void showSecondaryContacts() {
        TextView titleDisplay = findViewById(R.id.title_helpline);
        if (socialMediaRoot.getVisibility() == View.GONE){
            TransitionManager.beginDelayedTransition(titleRoot);
            tableLayout.setVisibility(View.GONE);
            socialMediaRoot.setVisibility(View.VISIBLE);
            titleDisplay.setText(R.string.social);
        }
        else {
            TransitionManager.beginDelayedTransition(titleRoot);
            socialMediaRoot.setVisibility(View.GONE);
            titleDisplay.setText(R.string.primary_helpline);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    tableLayout.setVisibility(View.VISIBLE);
                }
            }, 800);
        }
    }

    public String getFacebookPageURL(Context context) {
        PackageManager packageManager = context.getPackageManager();
        try {
            int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) {
                return "fb://facewebmodal/f?href=" + detailsList.get(0).getPrimaryContact().getFacebook();
            } else {
                return "fb://page/" + detailsList.get(0).getPrimaryContact().getFacebook();
            }
        } catch (PackageManager.NameNotFoundException ignored) { }
        return null;
    }

    private void fillDetails() {
        TextView locationDisplay;
        TextView helplineDisplay;
        TableRow tableRow;

        for (int i = 1; i < detailsList.size(); i++){
            DetailsModel details = detailsList.get(i);

            tableRow = new TableRow(this);
            locationDisplay = new TextView(this);
            helplineDisplay = new TextView(this);

            locationDisplay.setTextSize(15);
            locationDisplay.setTextColor(Color.WHITE);
            helplineDisplay.setTextSize(15);
            helplineDisplay.setTextColor(Color.WHITE);
            tableRow.setPadding(0,30,0,30);

            locationDisplay.setText(details.getLocation());
            helplineDisplay.setText(details.getHelplineNumber());
            Linkify.addLinks(helplineDisplay, Linkify.ALL);

            tableRow.addView(locationDisplay);
            tableRow.addView(helplineDisplay);
            tableLayout.addView(tableRow);
        }
    }

    private void fullScreenCall() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        decorView.setSystemUiVisibility(uiOptions);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.primary_fb:
                Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
                facebookIntent.setData(Uri.parse(getFacebookPageURL(this)));
                startActivity(facebookIntent);
                titleRoot.performClick();
                break;

            case R.id.primary_mail:
                Intent mailIntent = new Intent(Intent.ACTION_SENDTO);
                mailIntent.setData(Uri.parse("mailto:" + detailsList.get(0).getPrimaryContact().getEmail()));
                mailIntent.putExtra(Intent.EXTRA_SUBJECT, "Covid-19");
                startActivity(mailIntent);
                titleRoot.performClick();
                break;

            case R.id.primary_contact:
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:" + detailsList.get(0).getPrimaryContact().getNumber().trim()));
                startActivity(callIntent);
                titleRoot.performClick();
                break;

            case R.id.primary_twitter:
                Intent twitterIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(detailsList.get(0).getPrimaryContact().getTwitter()));
                try {
                    this.getPackageManager().getPackageInfo("com.twitter.android", 0);
                    twitterIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                } catch (Exception e) {
                    twitterIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(detailsList.get(0).getPrimaryContact().getTwitter()));
                }
                startActivity(twitterIntent);
                titleRoot.performClick();
                break;

            case R.id.title_container_helpline:
                showSecondaryContacts();
                break;

            case R.id.menu_helpline:
                titleRoot.performClick();
                break;
        }
    }


}