package com.zero.covid_19;

import com.zero.covid_19.Model.DetailsModel;

import java.util.ArrayList;
import java.util.List;

public interface AsyncResponse {
    void processFinished(List<DetailsModel> detailsList);
}