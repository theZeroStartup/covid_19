package com.zero.covid_19.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.zero.covid_19.AsyncResponse;
import com.zero.covid_19.Data.CovidData;
import com.zero.covid_19.Model.DetailsModel;
import com.zero.covid_19.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CollegesActivity extends AppCompatActivity {
    private List<DetailsModel> detailsList;
    private List<String> statesList;
    private List<String> typesList;
    private TableLayout collegesTable;
    private TableLayout filteredCollegesTable;
    private TableRow headingRow1;
    private TableRow headingRow2;

    private AlertDialog.Builder builder;
    private AlertDialog dialog;

    private ListView listView;
    private ArrayAdapter arrayAdapter;

    private FloatingActionButton clearFilters;
    private ImageButton additional;
    private RelativeLayout collegeMenu;
    private TextView locationDisplay;
    private TextView instituteDisplay;
    private TextView cityDisplay;
    private TextView instituteType;
    private TextView admissionCapacity;
    private TextView bedsCount;
    private TableRow tableRow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fullScreenCall();
        setContentView(R.layout.activity_colleges);

        Button filterByName = findViewById(R.id.filter_by_name);
        Button filterByType = findViewById(R.id.filter_by_type);
        collegesTable = findViewById(R.id.colleges_table);
        filteredCollegesTable = findViewById(R.id.filtered_colleges);
        collegeMenu = findViewById(R.id.title_container_college);
        headingRow2 = findViewById(R.id.heading_row_filter);
        headingRow1 = findViewById(R.id.heading_row_colleges);
        clearFilters = findViewById(R.id.clear_filters);
        additional = findViewById(R.id.college_menu);

        setStatesList(); setTypesList();
        clearFilters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        collegesTable.setVisibility(View.VISIBLE);
                        filteredCollegesTable.setVisibility(View.GONE);
                    }
                }, 500);
                clearFilters.setVisibility(View.GONE);
                collegeMenu.performClick();
            }
        });
        filterByName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFilterDialog(1);
            }
        });
        filterByType.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFilterDialog(2);
            }
        });

        additional.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                collegeMenu.performClick();
            }
        });
        collegeMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu();
            }
        });

        detailsList = new CovidData().getCollegeData(new AsyncResponse() {
            @Override
            public void processFinished(List<DetailsModel> detailsList) {
                fillDetails();
            }
        });
    }

    private void setTypesList() {
        typesList = new ArrayList<>();
        typesList.add("Govt");
        typesList.add("Trust");
        typesList.add("Society");
        typesList.add("University");
        typesList.add("Govt-Society");
        typesList.add("Private");
    }

    private void setStatesList() {
        statesList = new ArrayList<>();
        statesList.add("A & N Islands");
        statesList.add("Andhra pradesh");
        statesList.add("Assam");
        statesList.add("Tripura");
        statesList.add("Punjab");
        statesList.add("Rajasthan");
        statesList.add("Sikkim");
        statesList.add("Goa");
        statesList.add("Chandigarh");
        statesList.add("Chhattisgarh");
        statesList.add("Haryana");
        statesList.add("Himachal Pradesh");
        statesList.add("Jammu & Kashmir");
        statesList.add("Jharkhand");
        statesList.add("Karnataka");
        statesList.add("Maharastra");
        statesList.add("Manipur");
        statesList.add("Odisha");
        statesList.add("Puducherry");
        statesList.add("Tamil nadu");
        statesList.add("Telangana");
        statesList.add("Delhi");
        statesList.add("Gujarat");
        statesList.add("Kerala");
        statesList.add("Uttarakhand");
        statesList.add("Bihar");
        statesList.add("Uttar Pradesh");
        statesList.add("West bengal");
    }

    private void showFilterDialog(int selector) {
        collegeMenu.performClick();
        LayoutInflater inflater = getLayoutInflater();
        LinearLayout linearLayout = findViewById(R.id.filter_dialog_1);
        View view = inflater.inflate(R.layout.filter_dialog, linearLayout, false);
        listView = view.findViewById(R.id.states_list);
        TextView title = view.findViewById(R.id.title_filter);
        builder = new AlertDialog.Builder(this);
        builder.setView(view);
        dialog = builder.create();

        if (selector == 1){
            arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                    android.R.id.text1, statesList);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    filterTable(1, statesList.get(position));
                    clearFilters.setVisibility(View.VISIBLE);
                    dialog.dismiss();
                }
            });
        }
        else if (selector == 2){
            title.setText(R.string.filter_by_type);
            arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                    android.R.id.text1, typesList);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    filterTable(2, typesList.get(position));
                    clearFilters.setVisibility(View.VISIBLE);
                    dialog.dismiss();
                }
            });
        }
        listView.setAdapter(arrayAdapter);
        arrayAdapter.notifyDataSetChanged();

        dialog.show();
    }

    private void showMenu() {
        LinearLayout linearLayout = findViewById(R.id.linear_root_college);
        RelativeLayout relativeLayout = findViewById(R.id.title_container_college);

        if (linearLayout.getVisibility() == View.GONE){
            TransitionManager.beginDelayedTransition(relativeLayout);
            linearLayout.setVisibility(View.VISIBLE);
        }
        else
            linearLayout.setVisibility(View.GONE);
    }

    private void filterTable(int selector, String regex) {
        filteredCollegesTable.removeAllViews();
        filteredCollegesTable.addView(headingRow2);
        for (int i = 0; i < detailsList.size(); i++) {
            DetailsModel details = detailsList.get(i);
            String param;

            if (selector == 1)
                param = details.getLocation();
            else
                param = details.getInstituteType();

            if (param.trim().equalsIgnoreCase(regex)){
                addRow();
                bedsCount.setPadding(10,0,0,0);
                instituteType.setPadding(50,0,0,0);
                admissionCapacity.setPadding(10,0,0,0);
                instituteDisplay.setPadding(50,0,0,0);
                cityDisplay.setPadding(50,0,0,0);

                locationDisplay.setText(details.getLocation());
                instituteType.setText(details.getInstituteType());
                admissionCapacity.setText(String.valueOf(details.getAdmissionCapacity()));
                instituteDisplay.setText(details.getInstituteName());
                cityDisplay.setText(details.getCity());
                bedsCount.setText(String.valueOf(details.getInstituteBedCount()));

                tableRow.addView(locationDisplay);
                tableRow.addView(instituteDisplay);
                tableRow.addView(cityDisplay);
                tableRow.addView(instituteType);
                tableRow.addView(admissionCapacity);
                tableRow.addView(bedsCount);
                filteredCollegesTable.addView(tableRow);
            }
            collegesTable.setVisibility(View.GONE);
            filteredCollegesTable.setVisibility(View.VISIBLE);
        }
    }

    private void fillDetails() {
        collegesTable.removeAllViews();
        collegesTable.addView(headingRow1);
        for (int i = 1; i < detailsList.size(); i++){
            DetailsModel details = detailsList.get(i);
            addRow();

            locationDisplay.setText(details.getLocation());
            instituteType.setText(details.getInstituteType());
            admissionCapacity.setText(String.valueOf(details.getAdmissionCapacity()));
            instituteDisplay.setText(details.getInstituteName());
            cityDisplay.setText(details.getCity());
            bedsCount.setText(String.valueOf(details.getInstituteBedCount()));

            tableRow.addView(locationDisplay);
            tableRow.addView(instituteDisplay);
            tableRow.addView(cityDisplay);
            tableRow.addView(instituteType);
            tableRow.addView(admissionCapacity);
            tableRow.addView(bedsCount);
            collegesTable.addView(tableRow);
        }
    }

    private void addRow() {
        tableRow = new TableRow(this);
        locationDisplay = new TextView(this);
        instituteDisplay = new TextView(this);
        cityDisplay = new TextView(this);
        instituteType = new TextView(this);
        admissionCapacity = new TextView(this);
        bedsCount = new TextView(this);

        locationDisplay.setTextColor(Color.WHITE);
        instituteType.setTextColor(Color.WHITE);
        instituteType.setGravity(Gravity.CENTER);
        instituteType.setPadding(10,0,0,0);
        admissionCapacity.setTextColor(Color.WHITE);
        admissionCapacity.setGravity(Gravity.CENTER);
        admissionCapacity.setPadding(10,0,0,0);
        instituteDisplay.setTextColor(Color.WHITE);
        instituteDisplay.setPadding(10,0,0,0);
        cityDisplay.setTextColor(Color.WHITE);
        cityDisplay.setPadding(10,0,0,0);
        bedsCount.setTextColor(Color.WHITE);
        bedsCount.setGravity(Gravity.CENTER);

        tableRow.setPadding(5,30,0,30);
    }

    private void fullScreenCall() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        decorView.setSystemUiVisibility(uiOptions);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }
}