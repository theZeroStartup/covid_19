package com.zero.covid_19.Data;

import android.util.DisplayMetrics;
import android.util.Log;

import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.zero.covid_19.AsyncResponse;
import com.zero.covid_19.Controller.QueueSingletonController;
import com.zero.covid_19.Model.DetailsModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class CovidData {
    private List<DetailsModel> detailsList;


    public List<DetailsModel> getHelplineData(final AsyncResponse callback){
        final String url = "https://api.rootnet.in/covid19-in/contacts";
        detailsList = new ArrayList<>();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONObject("data").getJSONObject("contacts").getJSONArray("regional");
                    JSONObject jsonObject1 = response.getJSONObject("data").getJSONObject("contacts").getJSONObject("primary");

                    DetailsModel.PrimaryContact contact = new DetailsModel.PrimaryContact();
                    DetailsModel details1 = new DetailsModel();
                    contact.setNumber(jsonObject1.getString("number"));
                    contact.setEmail(jsonObject1.getString("email"));
                    contact.setFacebook(jsonObject1.getString("facebook"));
                    contact.setTwitter(jsonObject1.getString("twitter"));
                    details1.setPrimaryContact(contact);

                    detailsList.add(details1);

                    for (int i = 0; i < jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        DetailsModel details = new DetailsModel();
                        details.setLocation(jsonObject.getString("loc"));
                        details.setHelplineNumber(jsonObject.getString("number"));

                        detailsList.add(details);
                    }
                    if (callback != null)
                        callback.processFinished(detailsList);
                } catch (JSONException e) {
                    Log.d("TAG", "onResponse: " + e);
                    e.printStackTrace();
                }
            }
        }, null);

        QueueSingletonController.getInstance().addToRequestQueue(jsonObjectRequest);
        return detailsList;
    }

    public List<DetailsModel> getAdvisoryData(final AsyncResponse callback){
        final String url = "https://api.rootnet.in/covid19-in/notifications";
        detailsList = new ArrayList<>();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONObject("data").getJSONArray("notifications");
                    for (int i = 1; i < jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        DetailsModel detail = new DetailsModel();
                        detail.setAdvisoryLink(jsonObject.getString("link"));

                        String[] splitDateTitle;
                        if (jsonObject.getString("title").contains("&nbsp;"))
                            splitDateTitle = jsonObject.getString("title").split(";", 2);
                        else
                            splitDateTitle = jsonObject.getString("title").split(" ", 2);

                        detail.setDate(splitDateTitle[0].trim());
                        detail.setNotificationTitle(splitDateTitle[1].trim());

                        detailsList.add(detail);
                    }

                    if (callback != null)
                        callback.processFinished(detailsList);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, null);
        QueueSingletonController.getInstance().addToRequestQueue(jsonObjectRequest);
        return detailsList;
    }

    public List<DetailsModel> getHospitalData(final AsyncResponse callback){
        final String url = "https://api.rootnet.in/covid19-in/hospitals/beds";
        detailsList = new ArrayList<>();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONObject("data").getJSONArray("regional");
                    JSONObject summaryObject = response.getJSONObject("data").getJSONObject("summary");
                    DetailsModel.SummaryModel summaryModel = new DetailsModel.SummaryModel();
                    DetailsModel summaryDetails = new DetailsModel();

                    summaryModel.setOverallBeds(summaryObject.getInt("totalBeds"));
                    summaryModel.setOverallHospitals(summaryObject.getInt("totalHospitals"));
                    summaryModel.setOverallRuralBeds(summaryObject.getInt("ruralBeds"));
                    summaryModel.setOverallRuralHospitals(summaryObject.getInt("ruralHospitals"));
                    summaryModel.setOverallUrbanBeds(summaryObject.getInt("urbanBeds"));
                    summaryModel.setOverallUrbanHospitals(summaryObject.getInt("urbanHospitals"));

                    summaryDetails.setSummaryModel(summaryModel);
                    detailsList.add(summaryDetails);

                    for (int i = 0; i < jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        DetailsModel details = new DetailsModel();
                        details.setLocation(jsonObject.getString("state"));
                        details.setRuralHospitalCount(jsonObject.getInt("ruralHospitals"));
                        details.setRuralBedCount(jsonObject.getInt("ruralBeds"));
                        details.setUrbanHospitalCount(jsonObject.getInt("urbanHospitals"));
                        details.setUrbanBedCount(jsonObject.getInt("urbanBeds"));
                        details.setTotalHospitalCount(jsonObject.getInt("totalHospitals"));
                        details.setTotalBedCount(jsonObject.getInt("totalBeds"));

                        detailsList.add(details);
                    }

                    if (callback != null)
                        callback.processFinished(detailsList);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, null);
        QueueSingletonController.getInstance().addToRequestQueue(jsonObjectRequest);
        return detailsList;
    }

    public List<DetailsModel> getCollegeData(final AsyncResponse callback){
        final String url = "https://api.rootnet.in/covid19-in/hospitals/medical-colleges";
        detailsList = new ArrayList<>();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONObject("data").getJSONArray("medicalColleges");

                    for (int i = 0; i < jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        DetailsModel details = new DetailsModel();
                        details.setLocation(jsonObject.getString("state"));
                        details.setInstituteName(jsonObject.getString("name"));
                        details.setCity(jsonObject.getString("city"));
                        details.setInstituteType(jsonObject.getString("ownership"));
                        details.setAdmissionCapacity(jsonObject.getInt("admissionCapacity"));
                        details.setInstituteBedCount(jsonObject.getInt("hospitalBeds"));

                        detailsList.add(details);
                    }
                    if (callback != null)
                        callback.processFinished(detailsList);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, null);
        QueueSingletonController.getInstance().addToRequestQueue(jsonObjectRequest);
        return detailsList;
    }

}
