package com.zero.covid_19.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Column;
import com.anychart.enums.Anchor;
import com.anychart.enums.HoverMode;
import com.anychart.enums.Position;
import com.anychart.enums.TooltipPositionMode;
import com.zero.covid_19.Data.DatabaseHandler;
import com.zero.covid_19.Model.Patient;
import com.zero.covid_19.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CaseHistoryActivity extends AppCompatActivity {

    private AlertDialog.Builder builder;
    private AlertDialog dialog;
    private AnyChartView anyChartView;
    private AnyChartView anyChartView2;
    private TextView progressDisplay;
    private ImageButton casesMenu;
    private ProgressBar progressBar;

    private LinearLayout linearLayout;
    private RelativeLayout relativeLayout;
    private Button changeGraph;

    private boolean persistenceFlag;
    private static InputStream iStream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fullScreenCall();
        setContentView(R.layout.activity_case_history);

        anyChartView = findViewById(R.id.chart_view);
//        anyChartView2 = findViewById(R.id.chart_view2);
        progressBar = findViewById(R.id.chart_progress);
        anyChartView.setProgressBar(progressBar);
        casesMenu = findViewById(R.id.patients_menu);
        linearLayout = findViewById(R.id.linear_root_patients);
        relativeLayout = findViewById(R.id.patients_title_container);
        changeGraph = findViewById(R.id.change_graph);

        casesMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu();
            }
        });

        SharedPreferences preferences = getSharedPreferences("persistence", MODE_PRIVATE);
        persistenceFlag = preferences.getBoolean("persistenceFlag", true);
        iStream = getResources().openRawResource(R.raw.covid19india);
        downloadData();

        showGraph();
    }

    private void showMenu() {
        if (linearLayout.getVisibility() == View.GONE){
            TransitionManager.beginDelayedTransition(relativeLayout);
            anyChartView.setVisibility(View.GONE);
            linearLayout.setVisibility(View.VISIBLE);
        }
        else {
            TransitionManager.beginDelayedTransition(relativeLayout);
            linearLayout.setVisibility(View.GONE);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    anyChartView.setVisibility(View.VISIBLE);
                }
            }, 800);
        }
    }

//    private void showLocationGraph() {
//        if (!persistenceFlag){
//            DatabaseHandler patientDB = new DatabaseHandler(this);
//            List<Patient> patientList = patientDB.getPatientDetail(0, 9);
//
//            List<DataEntry> data = new ArrayList<>();
//            for (Patient patient: patientList){
//                if (!patient.getPatientStatus().equalsIgnoreCase("Recovered")){
//                    if (patient.getPatientAge().contains("-"))
//                        continue;
//                    if (patient.getPatientGender().isEmpty())
//                        patient.setPatientGender("Unspecified");
//                    data.add(new ValueDataEntry(patient.getPatientLocation(), Integer.valueOf(patient.getPatientAge())));
//                }
//
//            }
//
//            Cartesian cartesian = AnyChart.column();
//            Column column = cartesian.column(data);
//
//            column.tooltip()
//                    .titleFormat("{%X}")
//                    .position(Position.CENTER_BOTTOM)
//                    .anchor(Anchor.CENTER_BOTTOM)
//                    .offsetX(0d)
//                    .offsetY(5d)
//                    .format("${%Value}{groupsSeparator: }");
//
//            cartesian.animation(true);
//            cartesian.title("Covid-19 Deceased");
//
//            cartesian.yScale().minimum(0d);
//
//            cartesian.yAxis(0).labels().format("{%Value}{groupsSeparator: }");
//
//            cartesian.tooltip().positionMode(TooltipPositionMode.POINT);
//            cartesian.interactivity().hoverMode(HoverMode.BY_X);
//
//            cartesian.xAxis(0).title("Location");
//            cartesian.yAxis(0).title("Age");
//
//            anyChartView2.setChart(cartesian);
//        }
//    }

    private void showGraph() {
        if (!persistenceFlag){
            DatabaseHandler patientDB = new DatabaseHandler(this);
            List<Patient> patientList = patientDB.getPatientDetail(0, 9);

            List<DataEntry> data = new ArrayList<>();
            for (Patient patient: patientList){
                if (!patient.getPatientStatus().equalsIgnoreCase("Recovered")){
                    if (patient.getPatientAge().contains("-"))
                        continue;
                    if (patient.getPatientGender().isEmpty())
                        patient.setPatientGender("Unspecified");
                    data.add(new ValueDataEntry(patient.getPatientGender(), Integer.valueOf(patient.getPatientAge())));
                }

            }

            Cartesian cartesian = AnyChart.column();
            Column column = cartesian.column(data);

            column.tooltip()
                    .titleFormat("{%X}")
                    .position(Position.CENTER_BOTTOM)
                    .anchor(Anchor.CENTER_BOTTOM)
                    .offsetX(0d)
                    .offsetY(5d)
                    .format("${%Value}{groupsSeparator: }");

            cartesian.animation(true);
            cartesian.title("Covid-19 Deceased");

            cartesian.yScale().minimum(0d);

            cartesian.yAxis(0).labels().format("{%Value}{groupsSeparator: }");

            cartesian.tooltip().positionMode(TooltipPositionMode.POINT);
            cartesian.interactivity().hoverMode(HoverMode.BY_X);

            cartesian.xAxis(0).title("Gender");
            cartesian.yAxis(0).title("Age");

            anyChartView.setChart(cartesian);
        }
    }

    private void downloadData(){
        if (persistenceFlag){
            Toast.makeText(this, "This might take a minute or so!", Toast.LENGTH_LONG).show();
            new CRUD().execute();

            showProgressBar();
        }
    }

    private void showProgressBar() {
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.progress, null);
        view.setKeepScreenOn(true);
        progressDisplay = view.findViewById(R.id.progress_display);
        builder = new AlertDialog.Builder(CaseHistoryActivity.this);
        builder.setView(view);
        dialog = builder.create();
        dialog.setCancelable(false);
        dialog.show();
    }

    private class CRUD extends AsyncTask<Void, Void, Void> {
        public CRUD() {  }

        @Override
        protected Void doInBackground(Void... voids) {
            storePatientDetails();
            return null;
        }
    }

    private void storePatientDetails() {
        BufferedReader reader = new BufferedReader(new InputStreamReader(iStream, StandardCharsets.UTF_8));
        DatabaseHandler patientDB = new DatabaseHandler(this);
        String line;

        try {
            reader.readLine();

            int i = 0;
            while (((line = reader.readLine()) != null) && i < 10000) {
                i++;
                String[] tokens = line.split(",");

                if (tokens.length > 0){
                    Patient detail = new Patient();
                    detail.setPatientId(Integer.parseInt(tokens[0]));
                    detail.setReportedDate(tokens[1]);
                    detail.setPatientAge(tokens[3]);
                    detail.setPatientGender(tokens[4]);
                    detail.setPatientLocation(tokens[7]);
                    detail.setPatientStatus(tokens[8]);

                    patientDB.addPatient(detail);
                    progressDisplay.setText(MessageFormat.format("{0}/100", i / 100));
                }
            }

            SharedPreferences preferences = getSharedPreferences("persistence", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("persistenceFlag", false);
            editor.apply();
            editor.commit();
            dialog.dismiss();

            persistenceFlag = false;
            showGraph();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void fullScreenCall() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        decorView.setSystemUiVisibility(uiOptions);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }
}