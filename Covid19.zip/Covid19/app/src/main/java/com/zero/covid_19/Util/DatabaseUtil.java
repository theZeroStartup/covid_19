package com.zero.covid_19.Util;

public class DatabaseUtil {

    public static final String DATABASE_NAME = "covid_details";
    public static final String TABLE_NAME = "details_table";
    public static final int VERSION = 1;

    public static final String KEY_ID = "id";
    public static final String KEY_DATE = "reported_date";
    public static final String KEY_AGE = "age";
    public static final String KEY_GENDER = "gender";
    public static final String KEY_STATE = "state";
    public static final String KEY_STATUS = "status";
}
