package com.zero.covid_19.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.util.Linkify;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.zero.covid_19.AsyncResponse;
import com.zero.covid_19.Data.CovidData;
import com.zero.covid_19.Model.DetailsModel;
import com.zero.covid_19.R;

import java.util.List;
import java.util.Objects;

public class AdvisoryActivity extends AppCompatActivity {
    private List<DetailsModel> detailsList;
    private TableLayout tableLayout;
    private RelativeLayout titleRoot;
    private ImageButton additional;
    private TableRow tableRow;
    private LinearLayout menuContainer;
    private Button collapseTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fullScreenCall();
        setContentView(R.layout.activity_advisory);

        tableLayout = findViewById(R.id.advisory_table);
        final TextView titleDisplay = findViewById(R.id.advisory_title);
        final TextView linkDisplay = findViewById(R.id.link_display);
        collapseTable = findViewById(R.id.collapse_table);
        tableRow = findViewById(R.id.table_row_advisory);
        titleRoot = findViewById(R.id.advisory_title_container);
        menuContainer = findViewById(R.id.menu_container);
        additional = findViewById(R.id.advisory_menu);

        additional.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                titleRoot.performClick();
            }
        });
        titleRoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu();
            }
        });
        collapseTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                titleRoot.performClick();
                if (tableLayout.isColumnCollapsed(2)){
                    tableLayout.setColumnCollapsed(2, false);
                    tableLayout.setColumnCollapsed(1, true);
                    linkDisplay.setVisibility(View.VISIBLE);
                    titleDisplay.setVisibility(View.GONE);
                }
                else {
                    tableLayout.setColumnCollapsed(2, true);
                    tableLayout.setColumnCollapsed(1, false);
                    linkDisplay.setVisibility(View.GONE);
                    titleDisplay.setVisibility(View.VISIBLE);
                }
            }
        });

        detailsList = new CovidData().getAdvisoryData(new AsyncResponse() {
            @Override
            public void processFinished(List<DetailsModel> detailsList) {
                fillDetails();
            }
        });
        tableLayout.setColumnCollapsed(2, true);
    }

    private void showMenu() {
        if (menuContainer.getVisibility() == View.GONE){
            TransitionManager.beginDelayedTransition(titleRoot);
            tableLayout.setVisibility(View.GONE);
            tableRow.setVisibility(View.GONE);
            menuContainer.setVisibility(View.VISIBLE);
        }
        else {
            TransitionManager.beginDelayedTransition(titleRoot);
            menuContainer.setVisibility(View.GONE);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    tableLayout.setVisibility(View.VISIBLE);
                    tableRow.setVisibility(View.VISIBLE);
                }
            }, 800);
        }
    }

    private void fillDetails() {
        TextView dateDisplay;
        TextView titleDisplay;
        TextView linkDisplay;
        TableRow tableRow;

        for (int i = 0; i < detailsList.size(); i++){
            DetailsModel details = detailsList.get(i);

            tableRow = new TableRow(this);
            dateDisplay = new TextView(this);
            titleDisplay = new TextView(this);
            linkDisplay = new TextView(this);

            dateDisplay.setTextSize(15);
            dateDisplay.setTextColor(Color.WHITE);
            titleDisplay.setPadding(50,0,0,0);
            titleDisplay.setTextSize(15);
            titleDisplay.setTextColor(Color.WHITE);
            linkDisplay.setTextSize(15);
            linkDisplay.setTextColor(Color.WHITE);
            linkDisplay.setPadding(50,0,0,0);
            tableRow.setPadding(0,30,0,30);

            dateDisplay.setText(details.getDate());
            titleDisplay.setText(details.getNotificationTitle());
            linkDisplay.setText(details.getAdvisoryLink());
            Linkify.addLinks(linkDisplay, Linkify.ALL);

            tableRow.addView(dateDisplay);
            tableRow.addView(titleDisplay);
            tableRow.addView(linkDisplay);
            tableLayout.addView(tableRow);
        }

        tableLayout.setColumnShrinkable(1, true);
    }

    private void fullScreenCall() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        decorView.setSystemUiVisibility(uiOptions);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }
}