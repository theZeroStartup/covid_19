package com.zero.covid_19.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.zero.covid_19.Model.Patient;
import com.zero.covid_19.Util.DatabaseUtil;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    String CREATE_TABLE_COMMAND = "CREATE TABLE IF NOT EXISTS " + DatabaseUtil.TABLE_NAME
            + "("
            + DatabaseUtil.KEY_ID + " INTEGER PRIMARY KEY, "
            + DatabaseUtil.KEY_DATE + " TEXT, "
            + DatabaseUtil.KEY_AGE + " TEXT, "
            + DatabaseUtil.KEY_GENDER + " TEXT, "
            + DatabaseUtil.KEY_STATE + " TEXT, "
            + DatabaseUtil.KEY_STATUS + " TEXT);";

    public DatabaseHandler(@Nullable Context context) {
        super(context, DatabaseUtil.DATABASE_NAME, null, DatabaseUtil.VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_COMMAND);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE = "DROP TABLE IF EXISTS " + DatabaseUtil.TABLE_NAME;
        db.execSQL(DROP_TABLE);

        onCreate(db);
    }

    public void addPatient(Patient patient){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseUtil.KEY_DATE, patient.getReportedDate());
        values.put(DatabaseUtil.KEY_AGE, patient.getPatientAge());
        values.put(DatabaseUtil.KEY_GENDER, patient.getPatientGender());
        values.put(DatabaseUtil.KEY_STATE, patient.getPatientLocation());
        values.put(DatabaseUtil.KEY_STATUS, patient.getPatientStatus());

        db.insert(DatabaseUtil.TABLE_NAME, null, values);
        db.close();
    }

    public List<Patient> getPatientDetail(int limit1, int limit2) {
        List<Patient> patientList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + DatabaseUtil.TABLE_NAME + " WHERE " + DatabaseUtil.KEY_AGE + " BETWEEN "
                + (limit1) + " AND " + (limit2) + " ORDER BY ABS(age - " + limit2 + ");", null);

        if(cursor.moveToFirst()){
            do {
                Patient patient = new Patient();

                patient.setPatientId(cursor.getInt(0));
                patient.setReportedDate(cursor.getString(1));
                patient.setPatientAge(cursor.getString(2));
                patient.setPatientGender(cursor.getString(3));
                patient.setPatientLocation(cursor.getString(4));
                patient.setPatientStatus(cursor.getString(5));

                patientList.add(patient);

            }while(cursor.moveToNext());
        }

        cursor.close();
        return patientList;
    }

    public Patient getPatientDetail(String field, String regex) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(DatabaseUtil.TABLE_NAME,
                new String[]{DatabaseUtil.KEY_ID, DatabaseUtil.KEY_DATE, DatabaseUtil.KEY_AGE,
                        DatabaseUtil.KEY_GENDER, DatabaseUtil.KEY_STATE, DatabaseUtil.KEY_STATUS},
                field + "=?", new String[]{regex},
                null,null,null);

        if (cursor != null){
            cursor.moveToFirst();
        }

        Patient patient = new Patient();
        assert cursor != null;
        patient.setPatientId(cursor.getInt(0));
        patient.setReportedDate(cursor.getString(1));
        patient.setPatientAge(cursor.getString(2));
        patient.setPatientGender(cursor.getString(3));
        patient.setPatientLocation(cursor.getString(4));
        patient.setPatientStatus(cursor.getString(5));

        cursor.close();
        return patient;
    }
}
