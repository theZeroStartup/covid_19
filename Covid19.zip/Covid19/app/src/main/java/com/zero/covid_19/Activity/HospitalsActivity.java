package com.zero.covid_19.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.zero.covid_19.AsyncResponse;
import com.zero.covid_19.Data.CovidData;
import com.zero.covid_19.Model.DetailsModel;
import com.zero.covid_19.R;

import java.util.List;
import java.util.Objects;

public class HospitalsActivity extends AppCompatActivity {

    private List<DetailsModel> detailsList;
    private TableLayout regionalTable;
    private TableLayout summaryTable;
    private RelativeLayout menuButton;
    private Button changeTable;

    private ImageButton additional;
    private TextView locationDisplay;
    private TextView urbanHospitals;
    private TextView urbanBeds;
    private TextView ruralHospitals;
    private TextView ruralBeds;
    private TextView totalHospitals;
    private TextView totalBeds;
    private TableRow tableRow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fullScreenCall();
        setContentView(R.layout.activity_hospitals);

        regionalTable = findViewById(R.id.medical_table);
        summaryTable = findViewById(R.id.medical_summary_table);
        menuButton = findViewById(R.id.title_container_medical);
        changeTable = findViewById(R.id.change_table_medical);
        additional = findViewById(R.id.medical_menu);

        changeTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTable();
            }
        });
        additional.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menuButton.performClick();
            }
        });
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu();
            }
        });
        detailsList = new CovidData().getHospitalData(new AsyncResponse() {
            @Override
            public void processFinished(List<DetailsModel> detailsList) {
                fillRegionalDetails();
                fillSummaryDetails();
            }
        });
    }

    private void fillSummaryDetails() {
        addRow();
        ruralHospitals.setText(String.valueOf(detailsList.get(0).getSummaryModel().getOverallRuralHospitals()));
        ruralBeds.setText(String.valueOf(detailsList.get(0).getSummaryModel().getOverallRuralBeds()));
        urbanHospitals.setText(String.valueOf(detailsList.get(0).getSummaryModel().getOverallUrbanHospitals()));
        urbanBeds.setText(String.valueOf(detailsList.get(0).getSummaryModel().getOverallUrbanBeds()));
        totalHospitals.setText(String.valueOf(detailsList.get(0).getSummaryModel().getOverallHospitals()));
        totalBeds.setText(String.valueOf(detailsList.get(0).getSummaryModel().getOverallBeds()));

        tableRow.addView(ruralHospitals);
        tableRow.addView(ruralBeds);
        tableRow.addView(urbanHospitals);
        tableRow.addView(urbanBeds);
        tableRow.addView(totalHospitals);
        tableRow.addView(totalBeds);
        summaryTable.addView(tableRow);
    }

    private void changeTable() {
        TextView titleDisplay = findViewById(R.id.title_medical);
        if (summaryTable.getVisibility() == View.GONE){
            summaryTable.setVisibility(View.VISIBLE);
            regionalTable.setVisibility(View.GONE);
            titleDisplay.setText(R.string.total);
        }
        else{
            summaryTable.setVisibility(View.GONE);
            regionalTable.setVisibility(View.VISIBLE);
            titleDisplay.setText(R.string.regional);
        }
        menuButton.performClick();
    }

    private void showMenu() {
        LinearLayout linearLayout = findViewById(R.id.linear_root_medical);
        RelativeLayout relativeLayout = findViewById(R.id.title_container_medical);

        if (linearLayout.getVisibility() == View.GONE){
            TransitionManager.beginDelayedTransition(relativeLayout);
            linearLayout.setVisibility(View.VISIBLE);
        }
        else
            linearLayout.setVisibility(View.GONE);
    }

    private void fillRegionalDetails() {
        for (int i = 1; i < detailsList.size(); i++){
            DetailsModel details = detailsList.get(i);
            addRow();

            locationDisplay.setText(details.getLocation());
            ruralHospitals.setText(String.valueOf(details.getRuralHospitalCount()));
            ruralBeds.setText(String.valueOf(details.getRuralBedCount()));
            urbanHospitals.setText(String.valueOf(details.getUrbanHospitalCount()));
            urbanBeds.setText(String.valueOf(details.getUrbanBedCount()));
            totalHospitals.setText(String.valueOf(details.getTotalHospitalCount()));
            totalBeds.setText(String.valueOf(details.getTotalBedCount()));

            tableRow.addView(locationDisplay);
            tableRow.addView(ruralHospitals);
            tableRow.addView(ruralBeds);
            tableRow.addView(urbanHospitals);
            tableRow.addView(urbanBeds);
            tableRow.addView(totalHospitals);
            tableRow.addView(totalBeds);
            regionalTable.addView(tableRow);
        }
    }

    private void addRow() {
        tableRow = new TableRow(this);
        locationDisplay = new TextView(this);
        urbanHospitals = new TextView(this);
        urbanBeds = new TextView(this);
        ruralHospitals = new TextView(this);
        ruralBeds = new TextView(this);
        totalHospitals = new TextView(this);
        totalBeds = new TextView(this);

        locationDisplay.setTextColor(Color.WHITE);
        ruralHospitals.setTextColor(Color.WHITE);
        ruralHospitals.setGravity(Gravity.CENTER);
        ruralBeds.setTextColor(Color.WHITE);
        ruralBeds.setGravity(Gravity.CENTER);
        urbanHospitals.setTextColor(Color.WHITE);
        urbanHospitals.setGravity(Gravity.CENTER);
        urbanBeds.setTextColor(Color.WHITE);
        urbanBeds.setGravity(Gravity.CENTER);
        totalHospitals.setTextColor(Color.WHITE);
        totalHospitals.setGravity(Gravity.CENTER);
        totalBeds.setTextColor(Color.WHITE);
        totalBeds.setGravity(Gravity.CENTER);
        tableRow.setPadding(0,30,0,30);
    }

    private void fullScreenCall() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        decorView.setSystemUiVisibility(uiOptions);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }
}