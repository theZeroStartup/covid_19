package com.zero.covid_19.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;

import com.zero.covid_19.R;

import java.util.Objects;

public class MainMenuActivity extends AppCompatActivity implements View.OnClickListener {
    private CardView helpline;
    private CardView hospitals;
    private CardView colleges;
    private CardView advisory;
    private ImageButton graph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fullScreenCall();
        setContentView(R.layout.activity_main_menu);

        helpline = findViewById(R.id.helpline);
        hospitals = findViewById(R.id.hospitals);
        colleges = findViewById(R.id.colleges);
        advisory = findViewById(R.id.advisory);
        graph = findViewById(R.id.graph);

        helpline.setOnClickListener(this);
        hospitals.setOnClickListener(this);
        colleges.setOnClickListener(this);
        advisory.setOnClickListener(this);
        graph.setOnClickListener(this);
    }

    private void fullScreenCall() {
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        decorView.setSystemUiVisibility(uiOptions);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.helpline:
                startActivity(new Intent(MainMenuActivity.this, HelplineActivity.class));
                break;
            case R.id.hospitals:
                startActivity(new Intent(MainMenuActivity.this, HospitalsActivity.class));
                break;
            case R.id.colleges:
                startActivity(new Intent(MainMenuActivity.this, CollegesActivity.class));
                break;
            case R.id.advisory:
                startActivity(new Intent(MainMenuActivity.this, AdvisoryActivity.class));
                break;
            case R.id.graph:
                startActivity(new Intent(MainMenuActivity.this, CaseHistoryActivity.class));
                break;
        }
    }
}