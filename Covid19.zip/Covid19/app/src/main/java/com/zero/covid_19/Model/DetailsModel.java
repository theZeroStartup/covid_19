package com.zero.covid_19.Model;

public class DetailsModel {
    private String location;
    private String helplineNumber;
    private String date;
    private String notificationTitle;
    private String advisoryLink;
    private int ruralHospitalCount;
    private int ruralBedCount;
    private int urbanHospitalCount;
    private int urbanBedCount;
    private int totalBedCount;
    private int totalHospitalCount;
    private String instituteName;
    private String city;
    private String instituteType;
    private int admissionCapacity;
    private int instituteBedCount;
    private SummaryModel summaryModel;
    private PrimaryContact primaryContact;

    public DetailsModel() {
    }

    public PrimaryContact getPrimaryContact() {
        return primaryContact;
    }

    public void setPrimaryContact(PrimaryContact primaryContact) {
        this.primaryContact = primaryContact;
    }

    public SummaryModel getSummaryModel() {
        return summaryModel;
    }

    public void setSummaryModel(SummaryModel summaryModel) {
        this.summaryModel = summaryModel;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getHelplineNumber() {
        return helplineNumber;
    }

    public void setHelplineNumber(String helplineNumber) {
        this.helplineNumber = helplineNumber;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNotificationTitle() {
        return notificationTitle;
    }

    public void setNotificationTitle(String notificationTitle) {
        this.notificationTitle = notificationTitle;
    }

    public String getAdvisoryLink() {
        return advisoryLink;
    }

    public void setAdvisoryLink(String advisoryLink) {
        this.advisoryLink = advisoryLink;
    }

    public int getRuralHospitalCount() {
        return ruralHospitalCount;
    }

    public void setRuralHospitalCount(int ruralHospitalCount) {
        this.ruralHospitalCount = ruralHospitalCount;
    }

    public int getRuralBedCount() {
        return ruralBedCount;
    }

    public void setRuralBedCount(int ruralBedCount) {
        this.ruralBedCount = ruralBedCount;
    }

    public int getUrbanHospitalCount() {
        return urbanHospitalCount;
    }

    public void setUrbanHospitalCount(int urbanHospitalCount) {
        this.urbanHospitalCount = urbanHospitalCount;
    }

    public int getUrbanBedCount() {
        return urbanBedCount;
    }

    public void setUrbanBedCount(int urbanBedCount) {
        this.urbanBedCount = urbanBedCount;
    }

    public int getTotalBedCount() {
        return totalBedCount;
    }

    public void setTotalBedCount(int totalBedCount) {
        this.totalBedCount = totalBedCount;
    }

    public int getTotalHospitalCount() {
        return totalHospitalCount;
    }

    public void setTotalHospitalCount(int totalHospitalCount) {
        this.totalHospitalCount = totalHospitalCount;
    }

    public String getInstituteName() {
        return instituteName;
    }

    public void setInstituteName(String instituteName) {
        this.instituteName = instituteName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getInstituteType() {
        return instituteType;
    }

    public void setInstituteType(String instituteType) {
        this.instituteType = instituteType;
    }

    public int getAdmissionCapacity() {
        return admissionCapacity;
    }

    public void setAdmissionCapacity(int admissionCapacity) {
        this.admissionCapacity = admissionCapacity;
    }

    public int getInstituteBedCount() {
        return instituteBedCount;
    }

    public void setInstituteBedCount(int instituteBedCount) {
        this.instituteBedCount = instituteBedCount;
    }

    public static class PrimaryContact{
        private String facebook;
        private String twitter;
        private String number;
        private String email;

        public String getFacebook() {
            return facebook;
        }

        public void setFacebook(String facebook) {
            this.facebook = facebook;
        }

        public String getTwitter() {
            return twitter;
        }

        public void setTwitter(String twitter) {
            this.twitter = twitter;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }

    public static class SummaryModel{
        private int overallRuralHospitals;
        private int overallRuralBeds;
        private int overallUrbanHospitals;
        private int overallUrbanBeds;
        private int overallHospitals;
        private int overallBeds;

        public int getOverallRuralHospitals() {
            return overallRuralHospitals;
        }

        public void setOverallRuralHospitals(int overallRuralHospitals) {
            this.overallRuralHospitals = overallRuralHospitals;
        }

        public int getOverallRuralBeds() {
            return overallRuralBeds;
        }

        public void setOverallRuralBeds(int overallRuralBeds) {
            this.overallRuralBeds = overallRuralBeds;
        }

        public int getOverallUrbanHospitals() {
            return overallUrbanHospitals;
        }

        public void setOverallUrbanHospitals(int overallUrbanHospitals) {
            this.overallUrbanHospitals = overallUrbanHospitals;
        }

        public int getOverallUrbanBeds() {
            return overallUrbanBeds;
        }

        public void setOverallUrbanBeds(int overallUrbanBeds) {
            this.overallUrbanBeds = overallUrbanBeds;
        }

        public int getOverallHospitals() {
            return overallHospitals;
        }

        public void setOverallHospitals(int overallHospitals) {
            this.overallHospitals = overallHospitals;
        }

        public int getOverallBeds() {
            return overallBeds;
        }

        public void setOverallBeds(int overallBeds) {
            this.overallBeds = overallBeds;
        }

        @Override
        public String toString() {
            return "SummaryModel{" +
                    "overallRuralHospitals=" + overallRuralHospitals +
                    ", overallRuralBeds=" + overallRuralBeds +
                    ", overallUrbanHospitals=" + overallUrbanHospitals +
                    ", overallUrbanBeds=" + overallUrbanBeds +
                    ", overallHospitals=" + overallHospitals +
                    ", overallBeds=" + overallBeds +
                    '}';
        }
    }
}
